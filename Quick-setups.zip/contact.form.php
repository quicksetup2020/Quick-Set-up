<?php
$firsr-name = $_POST['firsr-name'];
$last-name = $_POST['last-name'];
$organisation-name = $_POST['organisation-name'];
$fvisitor_email = $_POST['email'];
$fvisitor_phone-number= $_POST['phon-number'];

$email_from = 'abbusinessline@gmail.com';

$email_subject = "New Form Submission";

$email_body = "User First Name: $first-name.\n".
               "User last Name: $last-name.\n".
               "User Organisation Name: $organisation-name.\n".
               "User Email: $visitor_email.\n".
               "User Phone Number: $phone-number.\n";

$to = "abiswas404@gmail.com";

$headers = "Form; $email_from \r\n";

$headers = "Reply-To; $visitor_email \r\n";

mail($to,$email_subject,$email_body,$headers);

header("Location: form.html");

 ?>
